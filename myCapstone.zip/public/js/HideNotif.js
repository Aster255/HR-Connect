function HideNotif() {
    $("#notif").slideUp();
    $(".notif").slideUp();
}

setTimeout(HideNotif, 2000);
