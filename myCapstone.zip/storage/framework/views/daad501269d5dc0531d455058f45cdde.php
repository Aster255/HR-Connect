<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make("Layout.Head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Admin</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/AdminShowDepartment.css')); ?>">
</head>

<body>
    <?php echo $__env->make("Layout.NavBarAdmin", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="greetings">
        <h1 class="Title_navbar" data-aos="zoom-in"><?php echo e($department->department_name); ?></h1>
    </div>

    <div class="button">
        <a class="btn btn-brand" href="/Admin/Organization">BACK</a>
        <a class="btn btn-brand" href="/Admin/Organization/Department/<?php echo e($department->department_id); ?>/edit" class="btn btn-primary">EDIT</a></td>
        <a class="btn btn-red" data-bs-toggle='modal' data-bs-target='#delete_<?php echo e($department->department_id); ?>'>DELETE</a>
        </td>
    </div>
    <div class="modal fade" id="delete_<?php echo e($department->department_id); ?>" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Confirm deletion of Department
                        <?php echo e($department->department_name); ?>

                    </h5>
                </div>
                <div class="modal-body">
                    Are you sure you want to delete this Department?
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        Close
                    </button>
                    <form action="/Admin/Organization/Department/<?php echo e($department->department_id); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-danger" type="submit">Delete</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="list">
        <div>
            <table class="Position_List">
                <thead class="table_section">
                    <th>ID</th>
                    <th>Name</th>
                    <th>Position</th>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="table_section">
                        <td><?php echo e($emp->position_id); ?></td>
                        <td><?php echo e($emp->first_name); ?> <?php echo e($emp->last_name); ?></td>
                        <td><?php echo e($emp->position_name); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>

            </table>
        </div>
        <div>
            <table class="Department_List">
                <thead class="table_section">
                    <th>ID</th>
                    <th>Position</th>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $position; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="table_section">
                        <td><?php echo e($pos->position_id); ?></td>
                        <td><?php echo e($pos->position_name); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>

            </table>
        </div>
    </div>

</body>


</html>

<script src="https://unpkg.com/aos@next/dist/aos.js"></script>
<script>
    AOS.init();
</script><?php /**PATH C:\Users\hajar\OneDrive\Documents\GITHUB\myCapstone\resources\views/AdminOrganization/ShowDepartment.blade.php ENDPATH**/ ?>