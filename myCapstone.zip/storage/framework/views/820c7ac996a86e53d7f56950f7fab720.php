<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make("Layout.Head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>System Admin</title>
    <?php echo $__env->make('Layout.Button', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <style>
        #realtime-date {
            margin-top: 20px;
            text-align: center;
            padding-block: 50px;
            background-color: rgba(146, 53, 232, 1);
            border-radius: 10px;
            font-size: 40px;
            color: white;
        }
    </style>
</head>

<body>
    <?php echo $__env->make("Layout.NavBarAdmin", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h1 class="Title_navbar" data-aos="zoom-in">LOG OUT</h1>

    <div class="row justify-content-center" data-aos="zoom-in">
        <div class="col-md-11">
            <p id="realtime-date"><?php echo e(date('h:i:s')); ?></p>
        </div>
    </div>
    <div class="row justify-content-center" data-aos="zoom-in">
        <div class="col-md-11">
            <form action="<?php echo e(route('Log.update', $attendance->attendance_id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <input type="submit" class="btn btn-red" style="width: 100%" value="LOG OUT">
            </form>
        </div>
    </div>
</body>

</html>
<script src="https://unpkg.com/aos@next/dist/aos.js"></script>
<script>
    AOS.init();
</script>
<script>
    function updateRealtimeDate() {
        var dateElement = document.getElementById('realtime-date');
        var currentDate = new Date();
        var formattedDate = currentDate.toLocaleString('en-GB', {
            hour12: false
        });
        dateElement.textContent = formattedDate;
    }
    updateRealtimeDate();
    setInterval(updateRealtimeDate, 1000);
</script><?php /**PATH C:\Users\hajar\OneDrive\Documents\GITHUB\myCapstone\HRconnect\resources\views/AdminAttendance/AttendanceLogOut.blade.php ENDPATH**/ ?>