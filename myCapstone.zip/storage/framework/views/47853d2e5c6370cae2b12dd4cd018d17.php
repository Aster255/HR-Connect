<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make("Layout.Head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>System Admin</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/AdminCreateLeave.css')); ?>">
</head>

<body>
    <?php echo $__env->make("Layout.NavBarAdmin", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="greetings">
        <h1 class="Title_navbar" data-aos="zoom-in">CREATE LEAVE TYPE</h1>
    </div>


    <div class="button">
        <a class="btn btn-brand" href="/Admin/Leave">BACK</a>
    </div>

    <div class="card">
        <div class="card-body">
            <form action="/Admin/Leave/Create" method="POST">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="leave_type_name">Leave Type: </label>
                    <input type="text" name="leave_type_name" id="leave_type_name">
                </div>
                <div class="form-group">
                    <input type="submit" class="btn btn-green" value="Create Leave Type">
                </div>

            </form>
        </div>
    </div>
    <div class="list">
        <table class="Position_List">
            <thead class="table_section">
                <th>leave ID</th>
                <th>Leave Type</th>
            </thead>
            <tbody>
                <?php $__currentLoopData = $leave; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="table_section
                    ">
                    <td><?php echo e($l->leavetype_id); ?></td>
                    <td><?php echo e($l->leave_type_name); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>


</body>

</html>

<script src="https://unpkg.com/aos@next/dist/aos.js"></script>
<script>
    AOS.init();
</script><?php /**PATH C:\Users\hajar\OneDrive\Documents\GITHUB\myCapstone\resources\views/AdminLeave/CreateLeave.blade.php ENDPATH**/ ?>