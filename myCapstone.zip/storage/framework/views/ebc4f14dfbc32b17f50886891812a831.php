<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make("Layout.Head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>System Admin</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/AdminEditPosition.css')); ?>">
</head>

<body>
    <?php echo $__env->make("Layout.NavBarAdmin", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="greetings">
        <h1 class="Title_navbar" data-aos="zoom-in"><?php echo e($position->position_name); ?></h1>
    </div>

    <div class="button">
        <a class="btn btn-brand" data-aos="zoom-in" href="/Admin/Organization/Position/<?php echo e($position->position_id); ?>">Back</a>
    </div>

    <div class="section_edit">
        <form action="/Admin/Organization/Position/<?php echo e($position->position_id); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="edit-seciton">
                <label for="position_name" class="current_name">Current Name: <?php echo e($position->position_name); ?></label>
                <div class="form-section">
                    <label for="new_position_name">New Name: </label>
                    <input type="text" name="new_position_name" id="new_position_name">
                    <input type="hidden" name="position_status" id="position_status" value="Update">
                </div>
                <div class="form-section">
                    <label for="department_id">Department (Do not change if not needed): </label>
                    <select name="department_id" id="department_id" required>

                        <option value="">Select Department</option>
                        <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($department->department_id); ?>" <?php if($department->department_id == $position->department_id): ?> selected <?php endif; ?>>
                            <?php echo e($department->department_name); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                </div>
                <input class="btn btn-green" type="submit" value="Confirm">
            </div>
        </form>
    </div>


</html>

<script src="https://unpkg.com/aos@next/dist/aos.js"></script>
<script>
    AOS.init();
</script><?php /**PATH C:\Users\hajar\OneDrive\Documents\GITHUB\myCapstone\resources\views/AdminOrganization/EditPosition.blade.php ENDPATH**/ ?>