<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make("Layout.Head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Admin</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/AdminEditDepartment.css')); ?>">
</head>

<body>
    <?php echo $__env->make("Layout.NavBarAdmin", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="greetings">
        <h1 class="Title_navbar" data-aos="zoom-in">EDIT: <?php echo e($department->department_name); ?></h1>
    </div>

    <div class="button">
        <a class="btn btn-brand" data-aos="zoom-in" href="/Admin/Organization">Back</a>
    </div>

    <div class="row justify-content-center" data-aos="zoom-in">
        <div class="col-md-8">
            <div class="card">
                <div class="card-body">
                    <form action="/Admin/Organization/Department/<?php echo e($department->department_id); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div>
                            <label for="department_name">Current Name: <?php echo e($department-> department_name); ?></label>
                        </div>

                        <div>
                            <label for="new_department_name">New Department Name: </label>
                            <input type="text" name="new_department_name" id="new_department_name">
                            <input type="hidden" name="department_status" id="department_status" value="Update">
                        </div>


                        <input class="btn btn-green" type="submit" value="Confirm">
                    </form>
                </div>
            </div>
        </div>
    </div>

</html>

<script src="https://unpkg.com/aos@next/dist/aos.js"></script>
<script>
    AOS.init();
</script><?php /**PATH C:\Users\hajar\OneDrive\Documents\GITHUB\myCapstone\resources\views/AdminOrganization/EditDepartment.blade.php ENDPATH**/ ?>