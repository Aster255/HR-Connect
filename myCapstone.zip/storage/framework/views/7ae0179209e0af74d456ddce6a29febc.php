<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make("Layout.Head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <title>System Admin</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/AdminShowPosition.css')); ?>">
</head>

<body>
    <?php echo $__env->make("Layout.NavBarAdmin", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="greetings">
        <h1 class="Title_navbar"><?php echo e($position->position_name); ?></h1>
    </div>

    <div class="button">
        <a class="btn btn-brand" href="/Admin/Organization">BACK</a>
        <a class="btn btn-green" href="/Admin/Organization/Position/<?php echo e($position->position_id); ?>/edit">EDIT</a>
        <a class="btn btn-red" data-bs-toggle='modal' data-bs-target='#delete_<?php echo e($position -> position_id); ?>'>DELETE</a>
    </div>

    <div class=" modal fade" id="delete_<?php echo e($position -> position_id); ?>" tabindex="-1" data-aos="zoom-in">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampositioneModalLabel">Confirm deletion of Position <?php echo e($position->
                        position_name); ?></h5>
                </div>
                <div class="modal-body">
                    Are you sure you want to delete this Position?
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-grey" data-bs-dismiss="modal">
                        Close
                    </button>
                    <form action="/Admin/Organization/Position/<?php echo e($position->position_id); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-red" style="margin-top: 3px;" type="submit">Delete</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    </div>

    <div class="list">
        <div>
            <table class="Position_List">
                <thead class="table_section">
                    <th>ID</th>
                    <th>Name</th>
                    <th>Department</th>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="table_section">
                        <td><?php echo e($emp->position_id); ?></td>
                        <td><?php echo e($emp->first_name); ?> <?php echo e($emp->last_name); ?></td>
                        <?php $__currentLoopData = $department; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dept): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td><?php echo e($dept->department_name); ?></td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</body>


</html>

<script src=" https://unpkg.com/aos@next/dist/aos.js">
</script>
<script>
    AOS.init();
</script><?php /**PATH C:\Users\hajar\OneDrive\Documents\GITHUB\myCapstone\resources\views/AdminOrganization/ShowPosition.blade.php ENDPATH**/ ?>