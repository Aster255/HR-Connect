<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make("Layout.Head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>System Admin</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/AdminAddDepartment.css')); ?>">

</head>

<body>
    <?php echo $__env->make("Layout.NavBarAdmin", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="greetings">
        <h1 class="Title_navbar" data-aos="zoom-in">ADD NEW DEPARTMENT</h1>
    </div>

    <div class="button">
        <a class="btn btn-brand" href="/Admin/Organization">Back</a>
    </div>
    <div class="row justify-content-center" data-aos="zoom-in">
        <div class="col-md-8">
            <div class="card">
                <div class="card-body">
                    <form action="<?php echo e(route('Department.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="department_name">Department Name: </label>
                            <input type="text" name="department_name" id="department_name" class="form-control" required>
                            <input type="hidden" name="department_status" value="added">
                        </div>

                        <input type="submit" class="btn btn-green" value="New Department" />
                    </form>
                </div>
            </div>
        </div>
    </div>

</body>

</html>

<script src="https://unpkg.com/aos@next/dist/aos.js"></script>
<script>
    AOS.init();
</script><?php /**PATH C:\Users\hajar\OneDrive\Documents\GITHUB\myCapstone\resources\views/AdminOrganization/AddDepartment.blade.php ENDPATH**/ ?>