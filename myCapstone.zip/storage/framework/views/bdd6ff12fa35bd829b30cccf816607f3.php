<!DOCTYPE html>
<html lang="en">

<head>
    <title>System Admin</title>
    <?php echo $__env->make('Layout.Head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/AdminCreateUser.css')); ?>">
</head>

<body>
    <?php echo $__env->make("Layout.Messege", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="greetings">
        <h1 class="Title_navbar" data-aos="zoom-in">CREATE NEW USER</h1>
    </div>
    <div class="button">
        <a class="btn btn-brand ms-2" href="Dashboard" data-aos="zoom-in">BACK</a>
    </div>


    <div class="section">
        <form action="/Admin/CreateUser" method="POST">
            <?php echo csrf_field(); ?>
            <div class="section_content">
                <label for="employee_id">Employee_id</label>
                <select name="employee_id" id="employee_id">
                    <option value="">Select Employee</option>
                    <?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($e->employee_id); ?>"><?php echo e($e->last_name); ?>, <?php echo e($e->first_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <label for="role">Select Role:</label>
                <select name="role" id="role">
                    <option value="">Select Role</option>
                    <?php $__currentLoopData = $role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($r->role_id); ?>"><?php echo e($r->role_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="divider"></div>
            <div class="section_content">
                <label for="username">User Name </label>
                <input type="text" name="username" id="username">
                <label for="password">Password: </label>
                <input type="password" name="password" id="password">
            </div>
            <input type="submit" class="btn btn-green" value="Create User">
        </form>
    </div>
</body>


<script>
    document.querySelector('')
</script>

</html><?php /**PATH C:\Users\hajar\OneDrive\Documents\GITHUB\myCapstone\resources\views/CreateUser.blade.php ENDPATH**/ ?>