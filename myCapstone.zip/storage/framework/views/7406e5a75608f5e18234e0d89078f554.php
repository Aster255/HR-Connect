<?php
$currentTime = date('H:i'); // Get the current time in 24-hour format (e.g., 13:30)
$greeting = '';
if ($currentTime >= '05:00' && $currentTime < '12:00') {
    $greeting = 'Good Morning';
} elseif ($currentTime >= '12:00' && $currentTime < '17:00') {
    $greeting = 'Good Afternoon';
} else {
    $greeting = 'Good Evening';
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make("Layout.Head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>System</title>
    <?php echo $__env->make('Layout.Button', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>


<body>
    <?php echo $__env->make("Layout.NavBarEmployee", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h1 class="Title_navbar" data-aos="zoom-in">DASHBOARD</h1>
    <div>
        <p><?php echo e($greeting); ?>! <?php echo e($employee->first_name); ?> <?php echo e($employee->last_name); ?>. Here's our agenda for today.</p>
    </div>

    <div class=" panel" data-aos="zoom-in">
        <div class="notification">
            <div class="notice">
                <h3>Notice</h3>
                <div class="notice_info">
                    <p>Hod approved OT of BIBI Garcia</p>
                    <p>thurs 7:00pm</p>
                </div>
                <div class="notice_info">
                    <p>Hod approved OT of BIBI Garcia</p>
                    <p>thurs 7:00pm</p>
                </div>
                <div class="notice_info">
                    <p>Hod approved OT of BIBI Garcia</p>
                    <p>thurs 7:00pm</p>
                </div>
            </div>
            <div class="event">
                <h3>Events</h3>
                <div class="event_info">
                    <p>SEMINAR: Healt and Remedy</p>
                    <p>Thurs 10:00AM- 11:30PM</p>
                </div>
                <div class="event_info">
                    <p>SEMINAR: Healt and Remedy</p>
                    <p>Thurs 10:00AM- 11:30PM</p>
                </div>
                <div class="event_info">
                    <p>SEMINAR: Healt and Remedy</p>
                    <p>Thurs 10:00AM- 11:30PM</p>
                </div>
            </div>
        </div>
</body>
<script src="https://unpkg.com/aos@next/dist/aos.js"></script>
<script>
    AOS.init();
</script>

</html><?php /**PATH C:\Users\hajar\OneDrive\Documents\GITHUB\myCapstone\HRconnect\resources\views/Employee/Dashboard.blade.php ENDPATH**/ ?>