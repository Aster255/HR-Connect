<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make("Layout.Head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>System Admin</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/CreateLeave.css')); ?>">
</head>

<body>
    <?php echo $__env->make("Layout.NavBarEmployee", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="greetings">
        <h1 class="Title_navbar" data-aos="zoom-in">Request Leave</h1>
    </div>

    <div class="button">
        <a class="btn btn-brand" href="/Leave">BACK</a>
    </div>

    <div class="card">
        <div class="card-body">
            <form action="/Leave" method="POST">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="start_date">start</label>
                    <input type="date" name="start_date" id="start_date">
                    <label for="end_date">end</label>
                    <input type="date" name="end_date" id="end_date">
                    <input type="text" hidden value="pending" name="status" id="status">
                </div>
                <div class="form-group">
                    <label for="leavetype_id">Leave Type</label>
                    <select name="leavetype_id" id="leavetype_id" required>
                        <option value=""></option>
                        <?php $__currentLoopData = $leavelist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leave): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($leave->leavetype_id); ?>"><?php echo e($leave->leave_type_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <input type="submit" class="btn btn-green" value="Request Leave">
            </form>
        </div>

    </div>
</body>

</html>

<script src="https://unpkg.com/aos@next/dist/aos.js"></script>
<script>
    AOS.init();
</script><?php /**PATH C:\Users\hajar\OneDrive\Documents\GITHUB\myCapstone\resources\views/Employee/CreateLeave.blade.php ENDPATH**/ ?>