<?php
$currentTime = date('H:i');
$greeting = '';
if ($currentTime >= '05:00' && $currentTime < '12:00') {
    $greeting = 'Good Morning';
} elseif ($currentTime >= '12:00' && $currentTime < '17:00') {
    $greeting = 'Good Afternoon';
} else {
    $greeting = 'Good Evening';
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make("Layout.Head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Admin</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/AdminDashboard.css')); ?>">
</head>

<body>
    <?php echo $__env->make("Layout.NavBarAdmin", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="greetings">
        <h1 class="Title_navbar">DASHBOARD</h1>

        <p class="agenda"><?php echo e($greeting); ?>! <?php echo e($employee->first_name); ?> <?php echo e($employee->last_name); ?>. here's our Agenda Today.</p>
    </div>

    <div class="panel">
        <div class="pending_leave">
            <a href="Employee">
                <h1 style="padding-block: 15px"><?php echo e($totalemployee); ?></h1>
                <p class="font-style">TOTAL EMPLOYEE</p>
            </a>
        </div>
        <div class="approved_leave">
            <a href="/Admin/Attendance/Log">
                <h1 style="padding-block: 15px"><?php echo e($totalEmployeesLoggedInToday); ?> / <?php echo e($totalemployee); ?></h1>
                <p class="font-style">EMPLOYEE TODAY</p>
            </a>
        </div>
        <div class="pending_overtime">
            <a href="/Admin/Leave">
                <h1 style="padding-block: 15px"><?php echo e($pendingLeaveCount); ?></h1>
                <p class="font-style">PENDING LEAVE</p>
            </a>
        </div>
        <div class="approved_overtime">
            <a href="/trial">
                <h1 style="padding-block: 15px">0</h1>
                <p class="font-style">PENDING OVERTIME</p>
            </a>
        </div>
    </div>

    <div class="notification">
        <div class="notice">
            <h3 class="font-style">Notice</h3>
            <div class="notice_content">
                <div class=" notice_info">
                    <p>Hod approved OT of BIBI Garcia</p>
                    <p>thurs 7:00pm</p>
                </div>
                <div class="notice_info">
                    <p>Hod approved OT of BIBI Garcia</p>
                    <p>thurs 7:00pm</p>
                </div>
                <div class="notice_info">
                    <p>Hod approved OT of BIBI Garcia</p>
                    <p>thurs 7:00pm</p>
                </div>
            </div>
        </div>

        <div class="event">
            <h3 class="font-style">Events</h3>
            <div class="event_content">
                <div class=" event_info">
                    <p>SEMINAR: Healt and Remedy</p>
                    <p>Thurs 10:00AM- 11:30PM</p>
                </div>
                <div class="event_info">
                    <p>SEMINAR: Healt and Remedy</p>
                    <p>Thurs 10:00AM- 11:30PM</p>
                </div>
                <div class="event_info">
                    <p>SEMINAR: Healt and Remedy</p>
                    <p>Thurs 10:00AM- 11:30PM</p>
                </div>
            </div>
        </div>
    </div>

</body>

<script src="https://unpkg.com/aos@next/dist/aos.js"></script>
<script>
    AOS.init();
</script>

</html><?php /**PATH C:\Users\hajar\OneDrive\Documents\GITHUB\myCapstone\resources\views/AdminDashboard/Dashboard.blade.php ENDPATH**/ ?>