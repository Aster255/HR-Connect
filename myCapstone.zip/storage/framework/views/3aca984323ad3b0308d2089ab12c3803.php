<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make("Layout.Head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>System Admin</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/Organization.css')); ?>">
</head>

<body>
    <?php echo $__env->make("Layout.NavBarAdmin", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="greetings">
        <h1 class="Title_navbar" data-aos="zoom-in">ORAGANIZATION</h1>
    </div>


    <div class="button" data-aos="zoom-in">
        <a class="btn btn-brand" href="/Admin/Organization/Position/create">ADD POSITION</a>
        <a class="btn btn-brand" href="/Admin/Organization/Department/create">ADD DEPARTMENT</a>
    </div>

    <div class="list">
        <div>
            <table class="Position_List">
                <thead>
                    <tr>
                        <th class="table_title" colspan="3">Position List</th>
                    </tr>
                    <tr class="table_section">
                        <th>ID</th>
                        <th>Name</th>
                        <th></th>
                    </tr>


                </thead>
                <?php if(count($positionlist) > 0): ?>
                <tbody>
                    <?php $__currentLoopData = $positionlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $position): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="table_section">
                        <td><?php echo e($position->position_id); ?></td>
                        <td><?php echo e($position->position_name); ?></td>

                        <td><a class="btn btn-brand ps-5 pe-5" href="/Admin/Organization/Position/<?php echo e($position->position_id); ?>">Information</a></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php echo e($positionlist->links('pagination::bootstrap-5')); ?>


            <?php else: ?>
            <p>No Data</p>
            <?php endif; ?>
        </div>
        <div>
            <table class="Department_List">
                <thead>
                    <tr>
                        <th colspan="3" class="table_title">Department List</th>
                    </tr>
                    <tr class="table_section">
                        <th>ID</th>
                        <th>Name</th>
                        <th></th>
                    </tr>

                </thead>
                <?php if(count($departmentlist) > 0): ?>
                <tbody>
                    <?php $__currentLoopData = $departmentlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="table_section">
                        <td><?php echo e($dl->department_id); ?></td>
                        <td><?php echo e($dl->department_name); ?></td>
                        <td><a class="btn btn-brand ps-5 pe-5" href="/Admin/Organization/Department/<?php echo e($dl->department_id); ?>">Information</a></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php echo e($departmentlist -> links('pagination::bootstrap-5')); ?>

            <?php else: ?>
            <p>No Data</p>
            <?php endif; ?>
        </div>
    </div>

</body>

</html>
<script src="https://unpkg.com/aos@next/dist/aos.js"></script>
<script>
    AOS.init();
</script><?php /**PATH C:\Users\hajar\OneDrive\Documents\GITHUB\myCapstone\resources\views/AdminOrganization/Organization.blade.php ENDPATH**/ ?>