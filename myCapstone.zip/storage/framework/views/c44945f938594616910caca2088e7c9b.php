<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make("Layout.Head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>System Admin</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/Attendance.css')); ?>">
</head>

<body>
    <?php echo $__env->make("Layout.NavBarEmployee", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="greetings">
        <h1 class="Title_navbar" data-aos="zoom-in">LOG IN</h1>
    </div>


    <div class="row justify-content-center" data-aos="zoom-in">
        <div class="col-md-11">
            <p id="realtime-date"><?php echo e(date('h:i:s')); ?></p>
        </div>
    </div>
    <div class="row justify-content-center" data-aos="zoom-in">
        <div class="col-md-11">
            <div class="card">
                <div class="card-body">
                    <form action="/Attendance" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label>Employee ID:</label>
                            <input disabled type="text" value="<?php echo e($employee->employee_id); ?>"></input>
                            <labe>Employee Name:</labe>
                            <input disabled type="text" value="<?php echo e($employee-> last_name); ?>, <?php echo e($employee-> first_name); ?>">
                            <input hidden type="text" value="<?php echo e($schedule->schedule_id); ?>">
                        </div>
                        <div class="form-group">
                            <select name="location_id" id="location_id" required>
                                <option value="">select one</option>
                                <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($location->location_id); ?>"><?php echo e($location->location); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="section">
                            <input type="submit" style="width: 100%" class="btn btn-green" value="LOG IN">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="row justify-content-center" data-aos="zoom-in">
        <div class="col-md-11">
            <form action="/Attendance" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <input type="submit" class="btn btn-red" style="width: 100%" value="LOG OUT">
            </form>
        </div>
    </div>



    <div>
        <div class="list">
            <table class="Position_List">
                <thead class="table_section">
                    <th>Attendance ID</th>
                    <th>Time Log In</th>
                    <th>Time Log Out</th>
                    <th>Date</th>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $attendance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class='table_section'>
                        <td><?php echo e($a->attendance_id); ?></td>
                        <td><?php echo e($a->in_time); ?></td>
                        <td><?php echo e($a->out_time); ?></td>
                        <td><?php echo e($a->attendance_date->format('Y-m-d')); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="4">No attendance records found.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
















</body>

</html>
<script src="https://unpkg.com/aos@next/dist/aos.js"></script>
<script>
    AOS.init();
</script>

<script>
    function updateRealtimeDate() {
        var dateElement = document.getElementById('realtime-date');
        var currentDate = new Date();
        var formattedDate = currentDate.toLocaleString('en-GB', {
            hour12: false
        });
        dateElement.textContent = formattedDate;
    }
    updateRealtimeDate();
    setInterval(updateRealtimeDate, 1000);
</script><?php /**PATH C:\Users\hajar\OneDrive\Documents\GITHUB\myCapstone\resources\views/Employee/Attendance.blade.php ENDPATH**/ ?>