<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make("Layout.Head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>System Admin</title>
    <?php echo $__env->make("layout.Button", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <style>
        .list {
            margin-right: 20px;
        }

        .list_one {
            background-color: var(--Nuetrals100);
            border-radius: 5px;

        }

        .list_two {
            background-color: var(--Nuetrals100);
            border-radius: 10px;
        }

        table {
            margin-block: 20px;
            width: 100%;
            text-align: center;
            border-radius: 10px;
        }

        th {
            padding-block: 10px;
        }

        td {
            padding-block: 10px;
        }
    </style>
</head>

<body>
    <?php echo $__env->make("Layout.NavBarAdmin", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h1 class="Title_navbar" data-aos="zoom-in">EMPLOYEE</h1>
    <div data-aos="zoom-in">
        <a class="btn btn-brand" href="/Admin/Employee/create">ADD EMPLOYEE</a>
    </div>
    <div class="list">
        <div class="list_one" data-aos="zoom-in">
            <table>
                <thead>
                    <th style="background-color: rgba(206, 212, 218, 1); border-top-left-radius: 10px;">Employee ID</th>
                    <th style="background-color: rgba(206, 212, 218, 1);">Employee Name</th>
                    <th style="background-color: rgba(206, 212, 218, 1);">Status</th>
                    <th style="background-color: rgba(206, 212, 218, 1); border-top-right-radius: 10px;">Date</th>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td style="width: 20%"><?php echo e($e->employee_id); ?></td>
                        <td style="width: 20%"><?php echo e($e->first_name); ?> <?php echo e($e->last_name); ?></td>
                        <td style="width: 20%"><?php echo e($e->employee_status); ?></td>
                        <td style="width: 20%"><?php echo e($e->employee_timestamp); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

        </div>
        <div class="list_two" data-aos="zoom-in">
            <table>
                <thead>
                    <tr>
                        <th colspan="4" style="background-color: rgba(206, 212, 218, 1); border-top-right-radius: 10px; border-top-left-radius: 10px;" colspan="3">Employee List</th>
                    </tr>
                    <tr>
                        <th style="width: 20%">Picture</th>
                        <th style="width: 10%">Employee ID</th>
                        <th style="width: 40%">Employee Name</th>
                        <th style="width: 30%"></th>
                    </tr>
                </thead>

                <tbody>
                    <tr>
                        <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><img src="/img/user_profiles/<?php echo e($e->picture); ?>" alt="<?php echo e($e->first_name); ?> pictures" width="100px"></td>
                        <td><?php echo e($e->employee_id); ?></td>
                        <td><?php echo e($e->first_name); ?> <?php echo e($e->last_name); ?></td>
                        <td>
                            <a class="btn btn-brand ps-5 pe-5" href="/Admin/Employee/<?php echo e($e->employee_id); ?>">info</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>


</body>

</html>

<script src="https://unpkg.com/aos@next/dist/aos.js"></script>
<script>
    AOS.init();
</script><?php /**PATH C:\Users\hajar\OneDrive\Documents\GITHUB\myCapstone\resources\views/AdminEmployee/Employee.blade.php ENDPATH**/ ?>