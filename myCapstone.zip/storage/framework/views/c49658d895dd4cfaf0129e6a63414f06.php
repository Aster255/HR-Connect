<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make("Layout.Head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>System Admin</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/AdminEmployee.css')); ?>">

</head>

<body>
    <?php echo $__env->make("Layout.NavBarAdmin", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="greetings">
        <h1 class="Title_navbar" data-aos="zoom-in">EMPLOYEE</h1>
    </div>

    <div class="button">
        <a class="btn btn-brand" href="/Admin/Employee/create">ADD EMPLOYEE</a>
    </div>
    <div class="list">
        <div class="list_one" data-aos="zoom-in">
            <table>
                <thead class="table_section">
                    <th>Employee ID</th>
                    <th>Employee Name</th>
                    <th>Status</th>
                    <th>Date</th>
                </thead>
                <tbody>
                    <?php
                    $hasUpdatesForToday = false;
                    ?>

                    <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                    $formattedDate = date('Y-m-d', strtotime($e->employee_timestamp));
                    ?>

                    <?php if($formattedDate == now()->toDateString()): ?>
                    <?php
                    $hasUpdatesForToday = true;
                    ?>

                    <tr class="table_section">
                        <td><?php echo e($e->employee_id); ?></td>
                        <td><?php echo e($e->first_name); ?> <?php echo e($e->last_name); ?></td>
                        <td><?php echo e($e->employee_status); ?></td>
                        <td><?php echo e($e->employee_timestamp); ?></td>
                    </tr>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php if(!$hasUpdatesForToday): ?>
                    <tr>
                        <td colspan="4" style='text-align: center;'>No available updates for today.</td>
                    </tr>
                    <?php endif; ?>

                </tbody>
            </table>

        </div>
        <div class="list_two" data-aos="zoom-in">
            <table>
                <thead>
                    <tr class="table_title">
                        <th colspan="4">Employee List</th>
                    </tr>
                    <tr class="table_section">
                        <th>Picture</th>
                        <th>Employee ID</th>
                        <th>Employee Name</th>
                        <th></th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="table_section">
                        <td><img src="/img/user_profiles/<?php echo e($e->picture); ?>" alt="<?php echo e($e->first_name); ?> pictures"
                                width="100px"></td>
                        <td><?php echo e($e->employee_id); ?></td>
                        <td><?php echo e($e->first_name); ?> <?php echo e($e->last_name); ?></td>
                        <td>
                            <a class="btn btn-brand ps-5 pe-5" href="/Admin/Employee/<?php echo e($e->employee_id); ?>">info</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>


</body>

</html>

<script src="https://unpkg.com/aos@next/dist/aos.js"></script>
<script>
    AOS.init();
</script><?php /**PATH C:\Users\hajar\OneDrive\Documents\GITHUB\myCapstone\resources\views/AdminEmployee/Employee.blade.php ENDPATH**/ ?>