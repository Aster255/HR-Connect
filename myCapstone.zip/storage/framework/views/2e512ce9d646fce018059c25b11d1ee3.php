<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make("Layout.Head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>System Admin</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/AdminAttendance.css')); ?>">
</head>

<body>
    <?php echo $__env->make("Layout.NavBarAdmin", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="greetings">
        <h1 class="Title_navbar" data-aos="zoom-in">ATTENDANCE</h1>
    </div>



    <div class="button">
        <a href="/Admin/Attendance/Log" class="btn btn-brand">Log List</a>
        <a href="/Admin/Attendance/Calendar" class="btn btn-brand">Calendar</a>
        <a href="/Admin/Attendance/Schedule" class="btn btn-brand">Schedule</a>
        <a href="/Admin/Attendance/Location" class="btn btn-brand">Location</a>
    </div>

    <div class="list">
        <div>
            <table class="Position_List">
                <thead>
                    <tr class="table_title">
                        <th colspan="3">Log In List</th>
                    </tr>
                    <tr class="table_section">
                        <th>Employee ID</th>
                        <th>Employee Name</th>
                        <th>Log In Time</th>
                    </tr>

                </thead>
                <tbody>
                <tbody>
                    <?php $__currentLoopData = $attendance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr class="table_section">
                        <td><?php echo e($a->employee_id); ?></td>
                        <?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($e->employee_id === $a->employee_id): ?>
                        <td><?php echo e($e->first_name); ?> <?php echo e($e->last_name); ?></td>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <td><?php echo e($a->in_time); ?></td>
                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <div>
            <table class="Position_List">
                <thead>
                    <tr class="table_title">
                        <th colspan="3">Log Out List</th>
                    </tr>
                    <tr class="table_section">
                        <th>Employee ID</th>
                        <th>Employee Name</th>
                        <th>Log Out Time</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $attendance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr class='table_section'>
                        <td><?php echo e($a->employee_id); ?></td>
                        <?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($e->employee_id === $a->employee_id): ?>
                        <td><?php echo e($e->first_name); ?> <?php echo e($e->last_name); ?></td>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <td><?php echo e($a->out_time); ?></td>
                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>

            </table>
        </div>
    </div>


</body>

</html>

<script src="https://unpkg.com/aos@next/dist/aos.js"></script>
<script>
    AOS.init();
</script><?php /**PATH C:\Users\hajar\OneDrive\Documents\GITHUB\myCapstone\resources\views/AdminAttendance/Attendance.blade.php ENDPATH**/ ?>