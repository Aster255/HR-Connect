<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make("Layout.Head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>System Admin</title>
    <?php echo $__env->make('Layout.Button', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <style>
        .list {
            margin-right: 20px;
        }

        .list_one {
            background-color: var(--Nuetrals100);
            border-radius: 5px;

        }

        .list_two {
            background-color: var(--Nuetrals100);
            border-radius: 10px;
        }

        table {
            margin-block: 20px;
            width: 100%;
            text-align: center;
            border-radius: 10px;
        }

        th {
            padding-block: 10px;
        }

        td {
            padding-block: 10px;
        }
    </style>
</head>

<body>
    <?php echo $__env->make("Layout.NavBarAdmin", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h1 class="Title_navbar" data-aos="zoom-in">ATTENDANCE</h1>


    <div data-aos="zoom-in">
        <a href="/Admin/Attendance/Log" class="btn btn-brand">Log List</a>
        <a href="/Admin/Attendance/Calendar" class="btn btn-brand">Calendar</a>
        <a href="/Admin/Attendance/Schedule" class="btn btn-brand">Schedule</a>
        <a href="/Admin/Attendance/Location" class="btn btn-brand">Location</a>
    </div>

    <!-- <div data-aos="zoom-in">
        <p><?php echo e($totalemployee); ?> / <?php echo e($totalEmployeesLoggedInToday); ?></p>
        <p>Total Employee Present</p>
    </div> -->

    <div class="list">
        <div class="list_one" data-aos="zoom-in">
            <table>
                <thead>
                    <tr>
                        <th colspan="3" style="background-color: rgba(206, 212, 218, 1); border-top-right-radius: 10px; border-top-left-radius: 10px;">Log In List</th>
                    </tr>
                    <tr>
                        <th style="background-color: rgba(206, 212, 218, 1); width: 30%;">Employee ID</th>
                        <th style="background-color: rgba(206, 212, 218, 1); width: 40%;">Employee Name</th>
                        <th style="background-color: rgba(206, 212, 218, 1);  width: 30%;">Log In Time</th>
                    </tr>

                </thead>
                <tbody>
                <tbody>
                    <?php $__currentLoopData = $attendance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr>
                        <td><?php echo e($a->employee_id); ?></td>
                        <?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($e->employee_id === $a->employee_id): ?>
                        <td><?php echo e($e->first_name); ?> <?php echo e($e->last_name); ?></td>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <td><?php echo e($a->in_time); ?></td>
                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <div class="list_two" data-aos="zoom-in">
            <table>
                <thead>
                    <tr>
                        <th colspan="3" style="background-color: rgba(206, 212, 218, 1); border-top-right-radius: 10px; border-top-left-radius: 10px;">Log Out List</th>
                    </tr>
                    <tr>
                        <th style="background-color: rgba(206, 212, 218, 1); width: 30%;">Employee ID</th>
                        <th style="background-color: rgba(206, 212, 218, 1); width: 40%;">Employee Name</th>
                        <th style="background-color: rgba(206, 212, 218, 1); width: 30%;">Log Out Time</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $attendance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr>
                        <td><?php echo e($a->employee_id); ?></td>
                        <?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($e->employee_id === $a->employee_id): ?>
                        <td><?php echo e($e->first_name); ?> <?php echo e($e->last_name); ?></td>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <td><?php echo e($a->out_time); ?></td>
                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>

            </table>
        </div>
    </div>


</body>

</html>

<script src="https://unpkg.com/aos@next/dist/aos.js"></script>
<script>
    AOS.init();
</script><?php /**PATH C:\Users\hajar\OneDrive\Documents\GITHUB\myCapstone\HRconnect\resources\views/AdminAttendance/Attendance.blade.php ENDPATH**/ ?>