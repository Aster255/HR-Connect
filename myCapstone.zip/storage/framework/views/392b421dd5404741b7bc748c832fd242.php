<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make('Layout.Head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/login.css')); ?>">
    <title>HRconnect</title>
</head>

<body class="login">
    <?php echo $__env->make("Layout.Messege", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="SignIn">
        <img src="/img/HRconnect_Name.png" />
        <div class="form-login">
            <form action="/" method="POST">
                <?php echo csrf_field(); ?>
                <label for="username">Username: </label>
                <input type="text" name="username"><br>

                <label for="password">Password: </label>
                <input type="password" name="password"><br>

                <input type="submit" value="Login">
            </form>
        </div>
    </div>
</body>

</html><?php /**PATH C:\Users\hajar\OneDrive\Documents\GITHUB\myCapstone\resources\views/Login.blade.php ENDPATH**/ ?>