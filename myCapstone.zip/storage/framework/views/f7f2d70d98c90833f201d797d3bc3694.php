<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make("Layout.Head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>System Admin</title>
    <?php echo $__env->make('Layout.Button', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <style>
        .list {
            margin-right: 20px;
        }

        .Position_List {
            background-color: var(--Nuetrals100);
            border-radius: 5px;

        }

        .Department_List {
            background-color: var(--Nuetrals100);
            border-radius: 10px;
        }

        table {
            margin-block: 20px;
            width: 100%;
            text-align: center;
            border-radius: 10px;
        }

        th {
            padding-block: 10px;
        }
    </style>
</head>

<body>
    <?php echo $__env->make("Layout.NavBarAdmin", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h1 class="Title_navbar" data-aos="zoom-in"><?php echo e($department->department_name); ?></h1>
    <div data-aos="zoom-in">
        <a class="btn btn-brand" href="/Admin/Organization">BACK</a>
        <a class="btn btn-brand" href="/Admin/Organization/Department/<?php echo e($department->department_id); ?>/edit" class="btn btn-primary">EDIT</a></td>
        <a class="btn btn-red" data-bs-toggle='modal' data-bs-target='#delete_<?php echo e($department->department_id); ?>'>DELETE</a></td>
    </div>
    <div class="modal fade" id="delete_<?php echo e($department->department_id); ?>" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Confirm deletion of Department <?php echo e($department->department_name); ?></h5>
                </div>
                <div class="modal-body">
                    Are you sure you want to delete this Department?
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        Close
                    </button>
                    <form action="/Admin/Organization/Department/<?php echo e($department->department_id); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-danger" type="submit">Delete</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="list">
        <div class="Position_List" data-aos="zoom-in">
            <table>
                <thead>
                    <th style="background-color: rgba(206, 212, 218, 1); border-top-left-radius: 10px;">ID</th>
                    <th style="background-color: rgba(206, 212, 218, 1);">Name</th>
                    <th style="background-color: rgba(206, 212, 218, 1); border-top-right-radius: 10px;">Position</th>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th><?php echo e($emp->position_id); ?></th>
                        <th><?php echo e($emp->first_name); ?> <?php echo e($emp->last_name); ?></th>
                        <th><?php echo e($emp->position_name); ?></th>

                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>

            </table>
        </div>
        <div class="Department_List " data-aos="zoom-in">
            <table>
                <thead>
                    <th style="background-color: rgba(206, 212, 218, 1); border-top-left-radius: 10px;">ID</th>
                    <th style=" background-color: rgba(206, 212, 218, 1); border-top-right-radius: 10px;">Position</th>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $position; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($pos->position_id); ?></td>
                        <td><?php echo e($pos->position_name); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>

            </table>
        </div>
    </div>
    </div>
</body>


</html>

<script src="https://unpkg.com/aos@next/dist/aos.js"></script>
<script>
    AOS.init();
</script><?php /**PATH C:\Users\hajar\OneDrive\Documents\GITHUB\myCapstone\HRconnect\resources\views/AdminOrganization/ShowDepartment.blade.php ENDPATH**/ ?>