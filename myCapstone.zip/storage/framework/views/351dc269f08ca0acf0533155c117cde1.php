<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make("Layout.Head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>System Admin</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/Leave.css')); ?>">
</head>

<body>
    <?php echo $__env->make("Layout.NavBarEmployee", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="greetings">
        <h1 class="Title_navbar" data-aos="zoom-in">LEAVE</h1>
    </div>


    <div class="button">
        <a class="btn btn-brand" href="/Leave/create">REQUEST LEAVE</a>
    </div>

    <div class="list">
        <table class="Position_List">
            <thead class="table_section">
                <th>leave ID</th>
                <th>Start Date</th>
                <th>End Date</th>
                <th>status</th>
            </thead>
            <tbody class="table_section">
                <?php $__currentLoopData = $leave; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($l->leave_id); ?></td>
                    <td><?php echo e($l->start_date); ?></td>
                    <td><?php echo e($l->end_date); ?></td>
                    <td><?php echo e($l->status); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</body>

</html>

<script src="https://unpkg.com/aos@next/dist/aos.js"></script>
<script>
    AOS.init();
</script><?php /**PATH C:\Users\hajar\OneDrive\Documents\GITHUB\myCapstone\resources\views/Employee/Leave.blade.php ENDPATH**/ ?>