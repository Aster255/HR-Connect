<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make("Layout.Head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>System Admin</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/AdminLocation.css')); ?>">
</head>

<body>
    <?php echo $__env->make("Layout.NavBarAdmin", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="greetings">
        <h1 class="Title_navbar" data-aos="zoom-in">LOCATION</h1>
    </div>


    <div class="button">
        <a class="btn btn-brand" href="/Admin/Attendance">Back</a>
    </div>
    <div class="row justify-content-center " style="  margin-right: 10px;" data-aos="zoom-in">
        <div>
            <div class="card">
                <div class="card-body">
                    <h2 class="section-title">Create Location</h2>
                    <form action="/Admin/Attendance/Location" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="Location">Location: </label>
                            <input type="text" id="Location" name="Location" required>
                        </div>
                        <input class="btn btn-green" type="submit" value="Create Location">
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="list" data-aos="zoom-in">
        <div class="list_one">
            <table>
                <thead>
                    <th style="background-color: rgba(206, 212, 218, 1); border-top-left-radius: 10px;">ID</th>
                    <th style="background-color: rgba(206, 212, 218, 1); border-top-right-radius: 10px;">location List</th>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $location; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($location->location_id); ?></td>
                        <td><?php echo e($location->location); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

</body>

</html>

<script src="https://unpkg.com/aos@next/dist/aos.js"></script>
<script>
    AOS.init();
</script><?php /**PATH C:\Users\hajar\OneDrive\Documents\GITHUB\myCapstone\resources\views/AdminAttendance/Location.blade.php ENDPATH**/ ?>