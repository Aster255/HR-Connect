<style>
    .Margin {
        margin-right: 20px;
    }

    table {
        margin-block: 20px;
        width: 100%;
        background-color: rgba(241, 243, 245, 1);
    }

    table,
    th,
    td {
        border: 1px solid white;
        border-collapse: collapse;
        text-align: center;
        text-transform: capitalize;
        font-size: 20px;
    }

    table th {
        background-color: rgba(222, 226, 230, 1);
        color: rgba(52, 58, 64, 1);
    }

    .btn {
        margin-top: 10px;
        background-color: rgba(181, 101, 241, 1);
        color: rgba(241, 243, 245, 1);
        padding: 8px;
        text-decoration: none;
        border-radius: 5px;
        border: none;
        cursor: pointer;
    }

    .btn:hover {
        background-color: rgba(113, 38, 199, 1);
        color: rgba(241, 243, 245, 1);
    }

    .list {
        display: flex;
        width: 100%;
    }

    .tablelist {
        flex: 1;
        flex-wrap: wrap;
        flex-shrink: 1;
        flex-grow: 1;
        min-width: 600px;
    }

    .tablelist table {
        margin-block: 20px;
        width: 100%;
        background-color: rgba(241, 243, 245, 1);
    }

    .tablelist table,
    .tablelist table th,
    .tablelist table th td {
        border: 1px solid white;
        border-collapse: collapse;
        text-align: center;
        text-transform: capitalize;
        font-size: 20px;
    }

    .tablelist table .tablelist table th {
        background-color: rgba(222, 226, 230, 1);
        color: rgba(52, 58, 64, 1);
    }
</style><?php /**PATH C:\Users\hajar\OneDrive\Documents\GITHUB\myCapstone\HRconnect\resources\views/Layout/table.blade.php ENDPATH**/ ?>