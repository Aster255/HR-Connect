<!DOCTYPE html>
<html lang="en">

<head>
    <title>System Admin</title>
</head>

<body>
    <?php echo $__env->make("Layout.Messege", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div>
        <p>BUTTONS</p>
    </div>
    <form action="/Admin/CreateUser" method="POST">
        <?php echo csrf_field(); ?>
        <label for="employee_id">Employee_id</label>
        <select name="employee_id" id="employee_id">
            <option value="">Select Employee</option>
            <?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($e->employee_id); ?>"><?php echo e($e->last_name); ?>, <?php echo e($e->first_name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <label for="role">Select Role:</label>
        <select name="role" id="role">
            <option value="admin">Admin</option>
            <option value="employee">Employee</option>
        </select>
        <hr>
        <label for="username">User Name </label>
        <input type="text" name="username" id="username">
        <br>
        <label for="password">Password: </label>
        <input type="password" name="password" id="password">

        <input type="submit" class="btn btn-success" value="Create User">
    </form>

</body>

</html>

<script src="https://unpkg.com/aos@next/dist/aos.js"></script>
<script>
    AOS.init();
</script><?php /**PATH C:\Users\hajar\OneDrive\Documents\GITHUB\myCapstone\HRconnect\resources\views/CreateUser.blade.php ENDPATH**/ ?>