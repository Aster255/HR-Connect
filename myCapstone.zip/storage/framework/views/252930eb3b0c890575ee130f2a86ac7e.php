<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make("Layout.Head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>System Admin</title>
    <?php echo $__env->make('Layout.Button', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <style>
        body {
            user-select: none;
        }

        .profile-picture {
            height: 300px;

        }

        .section {
            margin-bottom: 20px;
            border: 1px solid rgba(146, 53, 232, 1);
            padding: 50px;
            border-radius: 10px;
        }

        .section-title {
            font-weight: bold;
            color: rgba(146, 53, 232, 1);
            margin-bottom: 10px;
        }

        .section-content {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }

        .card-body {
            background-color: rgba(241, 243, 245, 1);

        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            font-weight: bold;
            color: rgba(59, 16, 134, 1);
            margin-bottom: 5px;
        }

        .none {
            background-color: gray;
            border: 1px solid rgba(41, 90, 111, 1);
        }

        .form-group input[type="text"],
        .form-group input[type="number"],
        .form-group input[type="tel"],
        .form-group input[type="email"],
        .form-group input[type="date"] {
            width: 100%;
            padding: 10px;
            border: 1px solid rgba(41, 10, 111, 1);
            border-radius: 5px;
            margin-bottom: 10px;
        }

        .form-group textarea {
            width: 100%;
            height: 100px;
            padding: 10px;
            border: 1px solid rgba(41, 10, 111, 1);
            border-radius: 5px;
        }

        .form-group select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ced4da;
            border-radius: 5px;
            background-color: white;
        }

        .top_section {
            display: flex;
            justify-content: space-between;
        }
    </style>
</head>

<body>
    <?php echo $__env->make("Layout.NavBarAdmin", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h1 class="Title_navbar" data-aos="zoom-in"><?php echo e($employee->first_name); ?> <?php echo e($employee->last_name); ?></h1>

    <div data-aos="zoom-in" class="mt-2">
        <a class="btn btn-brand" href="<?php echo e(route('Employee.index')); ?>">BACK</a>
        <a class="btn btn-brand" href="/Admin/Employee/<?php echo e($employee->employee_id); ?>/edit">EDIT</a>
        <a class="btn btn-danger" data-bs-toggle='modal' data-bs-target='#delete_<?php echo e($employee->employee_id); ?>'>DELETE</a>
    </div>


    <div class="modal fade" id="delete_<?php echo e($employee->employee_id); ?>" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Confirm deletion of Employee</h5>
                </div>
                <div class="modal-body">
                    Are you sure you want to delete this <?php echo e($employee->first_name); ?> <?php echo e($employee->last_name); ?>?
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        Close
                    </button>
                    <form action="/Admin/Employee/<?php echo e($employee->employee_id); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-red" type="submit">Delete</button>
                    </form>
                </div>
            </div>
        </div>
    </div>


    <div class="container-fluid mt-2" data-aos="zoom-in">

        <!-- Personal Information -->
        <div class="section">
            <div class="top_section">
                <h2 class="section-title">Personal Information</h2>
                <button type="button" class="btn btn-brand" data-toggle="modal" data-target="#EditpersonalInformation">
                    Edit
                </button>
            </div>


            <div class="section-content">
                <div class="form-group">
                    <label>Employee ID:</label>
                    <input disabled value="<?php echo e($employee->employee_id); ?>" type="text">
                </div>
                <div class="form-group">
                    <label>Title:</label>
                    <input disabled value="<?php echo e($employee->title); ?>" type="text">
                </div>
                <div class="form-group">
                    <label>First Name:</label>
                    <input disabled value="<?php echo e($employee->first_name); ?>" type="text">
                </div>
                <div class="form-group">
                    <label>Last Name:</label>
                    <input disabled value="<?php echo e($employee->last_name); ?>" type="text">
                </div>
                <div class="form-group">
                    <label>Maiden Name:</label>
                    <input disabled value="<?php echo e($employee->maiden_name ?: 'none'); ?>" type="text" class="<?php echo e($employee->maiden_name ?: 'none'); ?>">
                </div>
                <div class="form-group">
                    <label>Maiden Name:</label>
                    <input disabled value="<?php echo e($employee->maiden_name); ?>" type="text">
                </div>
                <div class="form-group">
                    <label>Nick Name:</label>
                    <input disabled value="<?php echo e($employee->nick_name); ?>" type="text">
                </div>
            </div>
        </div>


    </div>


    <div class="modal fade" id="EditpersonalInformation" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalCenterTitle">Modal title</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="/Admin/Employee/<?php echo e($employee->employee_id); ?>" enctype="multipart/form-data" method="POST" class="form-group">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <label for="title">Title</label>
                        <select name="title" id="title">
                            <option value="Mr" <?php if($employee->title === 'Mr'): ?> selected <?php endif; ?>>Mr.</option>
                            <option value="Mrs" <?php if($employee->title === 'Mrs'): ?> selected <?php endif; ?>>Mrs.</option>
                            <option value="Ms" <?php if($employee->title === 'Ms'): ?> selected <?php endif; ?>>Ms.</option>
                        </select>
                        <br>
                        <!-- first name -->
                        <label for="first_name">First Name:</label>
                        <input type="text" name="first_name" id="first_name" value="<?php echo e($employee->first_name); ?>">
                        <br>
                        <!-- middle name -->
                        <label for="last_name">Last Name:</label>
                        <input type="text" name="last_name" id="last_name" value="<?php echo e($employee->last_name); ?>">
                        <br>
                        <!-- last name -->
                        <label for="middle_name">Middle Name:</label>
                        <input type="text" name="middle_name" id="middle_name" value="<?php echo e($employee->middle_name); ?>">
                        <br>
                        <!-- maiden -->
                        <label for="maiden_name">Maiden Name:</label>
                        <input type="text" name="maiden_name" id="maiden_name" value="<?php echo e($employee->maiden_name); ?>">
                        <br>
                        <!-- nickname -->
                        <label for="nick_name">Nick Name:</label>
                        <input type="text" name="nick_name" id="nick_name" value="<?php echo e($employee->nick_name); ?>">

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save changes</button>
                </div>
                </form>
            </div>
        </div>
    </div>














    <!-- Department and Position -->
    <div class="section">
        <div class="top_section">
            <h2 class="section-title">Department and Position</h2>
            <button type="button" class="btn btn-brand" data-toggle="modal" data-target="#EditDepartment_Position">
                Edit
            </button>
        </div>

        <div class="section-content">
            <div class="form-group">
                <label>Department:</label>
                <input disabled value="<?php echo e($department->department_name); ?>" type="text">
            </div>
            <div class="form-group">
                <label>Position:</label>
                <input disabled value="<?php echo e($position->position_name); ?>" type="text">
            </div>
        </div>
    </div>

    <div class="modal fade" id="EditDepartment_Position" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalCenterTitle">Modal title</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="/Admin/Employee/<?php echo e($employee->employee_id); ?>" enctype="multipart/form-data" method="POST" class="form-group">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div>
                            <!-- position -->
                            <label for="position_id">Position:</label>
                            <select name="position_id" id="position_id">
                                <option value="">Select Position</option>
                                <?php $__currentLoopData = $positionlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($pos->position_id); ?>"><?php echo e($pos->position_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <br>
                            <!-- department -->
                            <label for="department_id">Department:</label>
                            <select name="department_id" id="department_id">
                                <option value="">Select Department</option>
                                <?php $__currentLoopData = $departmentlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dept): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($dept->department_id); ?>"><?php echo e($dept->department_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <br>
                            <!-- Salary -->
                            <label for="salary">Salary:</label>
                            <input type="number" name="salary" id="salary" min="5000">
                            <hr>
                        </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save changes</button>
                </div>
                </form>
            </div>
        </div>
    </div>












    <!-- Date of Birth, Nationality, Status, Gender -->
    <div class="section">
        <h2 class="section-title">Personal Information</h2>
        <div class="section-content">
            <div class="form-group">
                <label>Date of Birth:</label>
                <input disabled value="<?php echo e($employeeinformation->date_of_birth); ?>" type="text">
            </div>
            <div class="form-group">
                <label>Place of Birth:</label>
                <input disabled value="<?php echo e($employeeinformation->place_of_birth); ?>" type="text">
            </div>
            <div class="form-group">
                <label>Nationality:</label>
                <input disabled value="<?php echo e($employeeinformation->nationality); ?>" type="text">
            </div>
            <div class="form-group">
                <label>Status:</label>
                <input disabled value="<?php echo e($employeeinformation->status); ?>" type="text">
            </div>
            <div class="form-group">
                <label>Gender:</label>
                <input disabled value="<?php echo e($employeeinformation->gender); ?>" type="text">
            </div>
        </div>
    </div>

    <!-- Contact Information -->
    <div class="section">
        <h2 class="section-title">Contact Information</h2>
        <div class="section-content">
            <div class="form-group">
                <label>Mobile No:</label>
                <input disabled value="<?php echo e($employeeinformation->mobile_no); ?>" type="text">
            </div>
            <div class="form-group">
                <label>Phone No:</label>
                <input disabled value="<?php echo e($employeeinformation->phone_no); ?>" type="text">
            </div>
            <div class="form-group">
                <label>Email:</label>
                <input disabled value="<?php echo e($employeeinformation->email_address); ?>" type="text">
            </div>
            <div class="form-group">
                <label>Address:</label>
                <input disabled value="<?php echo e($employeeinformation->zip); ?>" type="text">
                <input disabled value="<?php echo e($employeeinformation->city); ?>" type="text">
                <input disabled value="<?php echo e($employeeinformation->street); ?>" type="text">
                <input disabled value="<?php echo e($employeeinformation->province); ?>" type="text">
            </div>
        </div>
    </div>

    <!-- Emergency Contact Information -->
    <div class="section">
        <h2 class="section-title">Emergency Contact Information</h2>
        <div class="section-content">
            <div class="form-group">
                <label>Name:</label>
                <input disabled value="<?php echo e($employeenotify->name); ?>" type="text">
            </div>
            <div class="form-group">
                <label>Relationship:</label>
                <input disabled value="<?php echo e($employeenotify->relationship); ?>" type="text">
            </div>
            <div class="form-group">
                <label>Mobile No:</label>
                <input disabled value="<?php echo e($employeenotify->mobile_no); ?>" type="text">
            </div>
            <div class="form-group">
                <label>Address:</label>
                <input disabled value="<?php echo e($employeenotify->address); ?>" type="text">
            </div>
        </div>
    </div>

    <!-- Contributions -->
    <div class="section">
        <h2 class="section-title">Contributions</h2>
        <div class="section-content">
            <div class="form-group">
                <label>SSS:</label>
                <input disabled value="<?php echo e($employeedoc->sss); ?>" type="text">
            </div>
            <div class="form-group">
                <label>TIN:</label>
                <input disabled value="<?php echo e($employeedoc->tin); ?>" type="text">
            </div>
            <div class="form-group">
                <label>PhilHealth:</label>
                <input disabled value="<?php echo e($employeedoc->philhealth); ?>" type="text">
            </div>
            <div class="form-group">
                <label>HDMF:</label>
                <input disabled value="<?php echo e($employeedoc->hdmf); ?>" type="text">
            </div>
        </div>
    </div>

    </div>

    <!-- <div>
        <h3>Educations</h3>
        <a class="btn btn-brand" href=" /SystemAdmin/SystemAdminEmployee/Employee">Add</a>
        <table class="table">
            <thead>
                <tr>
                    <th>Record No.</th>
                    <th>Level</th>
                    <th>School</th>
                    <th>Course</th>
                    <th>From</th>
                    <th>To</th>
                    <th>Edit</th>
                    <th>Delete</th>
                </tr>
            </thead>
            <tbody>
                <?php if(!empty($employeeeducation)): ?>
                <?php $__currentLoopData = $employeeeducation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $education): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($education->record_id); ?></td>
                    <td><?php echo e($education->level); ?></td>
                    <td><?php echo e($education->school); ?></td>
                    <td><?php echo e($education->course); ?></td>
                    <td><?php echo e($education->year_from); ?></td>
                    <td><?php echo e($education->year_to); ?></td>
                    <td>
                        <a href="<?php echo e(route('employee.education.edit', ['id' => $education->id])); ?>">Edit</a>
                    </td>
                    <td>
                        <form action="<?php echo e(route('employee.education.destroy', ['id' => $education->id])); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-red" type="submit">Delete</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <?php else: ?>
            <p>No education records found for this employee.</p>
            <?php endif; ?>
        </table>

    </div> -->

</body>

</html>

<script src="https://unpkg.com/aos@next/dist/aos.js"></script>
<script>
    AOS.init();
</script>




<?php /**PATH C:\Users\hajar\OneDrive\Documents\GITHUB\myCapstone\HRconnect\resources\views/AdminEmployee/ShowEmployee.blade.php ENDPATH**/ ?>