<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make("Layout.Head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>System Admin</title>
    <?php echo $__env->make('Layout.Button', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <style>
        .section {
            margin-bottom: 20px;
        }

        .section-title {
            font-weight: bold;
            color: rgba(146, 53, 232, 1);
            margin-bottom: 10px;
        }

        .section-content {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }

        .card-body {
            background-color: rgba(241, 243, 245, 1);
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            font-weight: bold;
            color: rgba(59, 16, 134, 1);
            margin-bottom: 5px;
        }

        .form-group input[type="text"] {
            width: 100%;
            padding: 10px;
            border: 1px solid rgba(41, 10, 111, 1);
            border-radius: 5px;
            margin-bottom: 10px;
        }

        .form-group select {
            width: 100%;
            padding: 10px;
            border: 1px solid rgba(41, 10, 111, 1);
            border-radius: 5px;
            background-color: white;
        }

        #realtime-date {
            margin-top: 20px;
            text-align: center;
            padding-block: 50px;
            background-color: rgba(146, 53, 232, 1);
            border-radius: 10px;
            font-size: 40px;
            color: white;
        }
    </style>
</head>

<body>
    <?php echo $__env->make("Layout.NavBarAdmin", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h1 class="Title_navbar" data-aos="zoom-in">LOG IN</h1>

    <div class="row justify-content-center" data-aos="zoom-in">
        <div class="col-md-11">
            <p id="realtime-date"><?php echo e(date('h:i:s')); ?></p>
        </div>
    </div>
    <div class="row justify-content-center" data-aos="zoom-in">
        <div class="col-md-11">
            <div class="card">
                <div class="card-body">
                    <form action="/Admin/Attendance/Log" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="employee_id">Employee Name: </label>
                            <select name="employee_id" id="employee_id" required>
                                <option value="">Name</option>
                                <?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($employee->employee_id); ?>"><?php echo e($employee-> last_name); ?>, <?php echo e($employee-> first_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <select name="location_id" id="location_id" required>
                                <option value="">select one</option>
                                <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($location->location_id); ?>"><?php echo e($location->location); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="section">
                            <input type="submit" class="btn btn-green" value="LOG IN">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>

</html>
<script src="https://unpkg.com/aos@next/dist/aos.js"></script>
<script>
    AOS.init();
</script>

<script>
    function updateRealtimeDate() {
        var dateElement = document.getElementById('realtime-date');
        var currentDate = new Date();
        var formattedDate = currentDate.toLocaleString('en-GB', {
            hour12: false
        });
        dateElement.textContent = formattedDate;
    }
    updateRealtimeDate();
    setInterval(updateRealtimeDate, 1000);
</script><?php /**PATH C:\Users\hajar\OneDrive\Documents\GITHUB\myCapstone\HRconnect\resources\views/AdminAttendance/AttendanceLogIn.blade.php ENDPATH**/ ?>